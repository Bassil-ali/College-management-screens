<li>
    <div class="uk-text-center">
        <img class="uk-width-1-2 uk-margin-xlarge-top" data-src="{{ url('images/cte.jpg') }}" alt="cte.jpg" uk-img>
    </div>
</li>
